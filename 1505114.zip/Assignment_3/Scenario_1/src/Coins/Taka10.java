package Coins;

public class Taka10 implements Coin {
    @Override
    public int Value() {
        return 10;
    }

    @Override
    public String Name() {
        return "BDT 10";
    }


}
