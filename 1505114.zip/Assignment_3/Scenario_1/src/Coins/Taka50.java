package Coins;

public class Taka50 implements Coin {
    @Override
    public int Value() {
        return 50;
    }

    @Override
    public String Name() {
        return "BDT 50";
    }


}
