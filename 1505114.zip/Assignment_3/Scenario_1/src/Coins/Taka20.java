package Coins;

public class Taka20 implements Coin {
    @Override
    public int Value() {
        return 20;
    }

    @Override
    public String Name() {
        return "BDT 20";
    }

}
