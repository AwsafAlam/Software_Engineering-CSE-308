package Coins;

public class Taka5 implements Coin {
    @Override
    public int Value() {
        return 5;
    }

    @Override
    public String Name() {
        return "BDT 5";
    }
}
