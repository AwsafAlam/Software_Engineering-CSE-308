package Coins;

public interface Coin {
    public int Value();
    public String Name();
}
