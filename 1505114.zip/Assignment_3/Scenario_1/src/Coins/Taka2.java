package Coins;

public class Taka2 implements Coin {
    @Override
    public int Value() {
        return 2;
    }

    @Override
    public String Name() {
        return "BDT 2";
    }

}
