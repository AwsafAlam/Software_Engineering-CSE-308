package Coins;

public class Taka1 implements Coin{

    @Override
    public int Value() {
        return 1;
    }

    @Override
    public String Name() {
        return "BDT 1";
    }
}
