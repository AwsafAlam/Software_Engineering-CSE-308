package Drinks;

public interface SoftDrinks {
    public String Name();
    public int Price();
}
